declare var WebAssembly: {
    instantiate(buffer: ArrayBuffer | Uint8Array, importObject?: any): Promise<WebAssembly.WebAssemblyInstantiatedSource>;
};
