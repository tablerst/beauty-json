import { WASI } from 'wasi';
import * as fs from 'fs';
import * as path from 'path';

// Initialize WASI instance
const wasi = new WASI({
    version: 'preview1',
    args: [],
    env: process.env,
    preopens: {
        '/sandbox': path.resolve('.')
    }
});

// Load WebAssembly module
const wasmFilePath = './static/main.wasm';
const wasmBuffer = fs.readFileSync(wasmFilePath);

(async () => {
    try {
        const { instance } = await WebAssembly.instantiate(wasmBuffer, {
            wasi_snapshot_preview1: wasi.wasiImport
        });
        console.log("WASM module loaded successfully!");

        // Start the WASI instance
        wasi.start(instance);
        console.log("WASM module running!");

    } catch (err) {
        console.error("Failed to load WASM:", err);
    }
})();

// npx ts-node ./src/main.ts

// tsc ./src/main.ts
// node ./src/main.js